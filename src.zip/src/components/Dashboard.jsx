import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function Dashboard() {

  const [data, SetData] = useState([]);

  const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjE3MTkwMjk1MjgyNjEtNzIxODM2NTkyIiwiaWF0IjoxNzE5MDI5NTI4LCJleHAiOjE3MTkyMDIzMjh9.vIYEVcS0x3mbstpkBb_AE6TQRvJQ0r7nk_ZoduDgYwo'

  useEffect(() => {
    axios.get('https://service.apikeeda.com/contact-book',
      {
        headers: { Authorization: token }
      }
    )
      .then(function (response) {
        // console.log(response.data);
        SetData(response.data.data)
      })

  }, [])

  return (
    <>
      <Link to={'/viewcon'}>
        <div className=' bg-[#0d1b2a] flex flex-col justify-center items-center w-[300px] h-[250px]'>
          <h1 className='text-white m-0 text-[24px]'>Total contact</h1>
          <p className='text-white text-[22px] mt-2'>{ data.length}</p>
        </div>
      </Link>

    </>
  )
}